/*! FEAM.js > A jQuery Front End Admin Menu, v0.2 
 *
 * Copyright 2014, Matthias Gattermeier 
 *
 * www.gattermeier.net
 *
 * Date: 2014-06-03
 *
 */

FrontendAdminMenu = function(opt){
    var defaults = { 
        Button:  '#feam-btn', 
        Content: '#feam-content',
        Menu:    '#feam-menu', 
        Panes:   '.feam-tab-pane',
        Off:     '#feam-off',
    };
    var opt = $.extend({}, defaults, opt);
    (opt.Links) = $(opt.Menu).find('li a');
  
    // let connect menu elements with their panes
    $(opt.Links).each(function( index, element ) {
        var value = "#feam-menu-target-"+index;
        var attributeName = "data-target";
        $( this ).attr( attributeName, value );
    });
    
    $(opt.Panes).each(function( index, element ) {
        var value = "feam-menu-target-"+index;
        var attributeName = "ID";
        $( this ).attr( attributeName, value );
    });
    
    // because jQuery got rid of the beloved .toggle()
    $.fn.toggleClick = function(){
        var functions = arguments;
        return this.click(function(){
                var iteration = $(this).data('iteration') || 0;
                functions[iteration].apply(this, arguments);
                iteration = (iteration + 1) % functions.length ;
                $(this).data('iteration', iteration);
        }) ;
    };
    
    // close Menu
    closeMenu = function(target){
        if (target == 'all') {
            $(opt.Button).addClass('icon-cog').removeClass('icon-close');
            $(opt.Content).removeClass( "feam-btn-open fullwidth" );
            $(opt.Panes).removeClass("active");            
        }

    };
    
    //open menu
    openMenu = function(target){
        if (target == 'menu') {
            $(opt.Button).addClass('icon-close').removeClass('icon-cog');
            $(opt.Content).addClass( "feam-btn-open" );
        }
    };
    
    //open and close menu event
    $(opt.Button).toggleClick(function(){
        openMenu('menu');
        },function(){
            closeMenu('all');
    });
    
    // Push main content right when opening menu
    $(opt.Button).click(function(){
        $(opt.Off).toggleClass("push"); 
    });
    
    // Menu Links open Panes
    $(opt.Links).click(function(){
        var target = $($(this).data("target"));
    
        target.toggleClass('active').siblings().removeClass('active');
        
        if(target.hasClass("active")){
             $(opt.Content).addClass('fullwidth');
            } else {
                $(opt.Content).removeClass('fullwidth');
                }

    });
    };